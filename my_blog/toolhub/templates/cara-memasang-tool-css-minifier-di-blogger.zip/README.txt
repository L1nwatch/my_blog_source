A Pen created at CodePen.io. You can find this one at http://codepen.io/arlinadesign/pen/KVNBKK.

 Cara Memasang Tool CSS Minifier di Blogger